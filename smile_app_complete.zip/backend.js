
// backend.js
app.post('/signup', async (req, res) => {
    const { email, password, acceptedTerms } = req.body;
    if (!acceptedTerms) {
        return res.status(400).send("You must accept the Terms and Conditions to sign up.");
    }
    const newUser = await User.create({ email, password, acceptedTerms: true });
    res.status(201).send("Account Created Successfully.");
});

app.post('/post', async (req, res) => {
    const { userId, content } = req.body;
    const isInappropriate = checkContentForInappropriateBehavior(content);
    if (isInappropriate) {
        await logUserViolation(userId);
        await sendWarningToUser(userId);
        const violationCount = await getUserViolationCount(userId);
        if (violationCount >= 3) {
            await deleteUserAccount(userId);
            res.status(403).send("Account deleted due to repeated violations.");
            return;
        }
    }
    res.status(200).send("Content posted successfully.");
});

app.delete('/delete-account', async (req, res) => {
    const { userId } = req.body;
    const hasPendingViolations = await checkPendingViolations(userId);
    if (hasPendingViolations) {
        return res.status(403).send("Your account deletion request is under review due to pending violations.");
    }
    await deleteUserAccount(userId);
    res.status(200).send("Account deleted successfully.");
});
