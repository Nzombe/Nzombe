from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
app = FastAPI()

class User(BaseModel):
    email: str
    phone: str
    password: str
    acceptedTerms: bool

@app.get("/terms")
async def terms():
    return {"title":"Terms and Conditions","content":"Full terms here..."}

@app.get("/privacy")
async def privacy():
    return {"title":"Privacy Policy","content":"Full privacy policy here..."}

@app.post("/signup")
async def signup(user: User):
    if not user.acceptedTerms:
        raise HTTPException(status_code=400, detail="Terms not accepted")
    if user.email=="nzombet43@gmail.com" or user.phone=="+263872578565":
        return {"message":"Welcome Admin","panel":"admin"}
    return {"message":"Welcome User","panel":"user"}