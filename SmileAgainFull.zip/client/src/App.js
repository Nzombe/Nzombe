import React, { useState, useEffect } from 'react';
import Loading from './Loading';
import Signup from './Signup';
import { auth } from './firebase';

function App() {
  const [stage, setStage] = useState('loading');
  useEffect(() => {
    // show terms first
    setStage('terms');
  }, []);

  if(stage === 'loading') return <Loading />;
  if(stage === 'terms') return <div>'[Terms and Conditions loaded here]'<button onClick={() => setStage('signup')}>Accept</button></div>;
  return <Signup />;
}

export default App;