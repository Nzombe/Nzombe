import React from 'react';
import './Loading.css';

const Loading = () => {
  return (
    <div className="loading-container">
      <div className="sky">
        <div className="sun"></div>
        <div className="cloud"></div>
        <div className="moon"></div>
      </div>
    </div>
  );
}

export default Loading;