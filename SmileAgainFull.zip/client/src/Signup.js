import React, { useState } from 'react';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [accepted, setAccepted] = useState(false);
  const handleSubmit = () => {
    if(!accepted) return alert('Accept terms');
    // redirect logic
    window.location.href = '/api/signup';
  }
  return (
    <div>
      <h2>Sign Up</h2>
      <input placeholder="Email" onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="Phone" onChange={e=>setPhone(e.target.value)} /><br/>
      <div>
        <input type="checkbox" onChange={e=>setAccepted(e.target.checked)} /> I accept <a href="terms-and-conditions.html">Terms</a> & <a href="privacy-policy.html">Privacy</a>
      </div>
      <button onClick={handleSubmit}>Sign Up</button>
    </div>
  );
}