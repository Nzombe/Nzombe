# Block 17

Description and implementation details for Block 17 go here.