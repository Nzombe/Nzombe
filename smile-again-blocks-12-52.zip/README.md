# Smile Again App
This app includes frontend, backend, and Firebase config.