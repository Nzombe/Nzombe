
import React from 'react';
import Loading from './Loading';

function App() {
  return (
    <div className="App">
      <Loading />
    </div>
  );
}

export default App;
